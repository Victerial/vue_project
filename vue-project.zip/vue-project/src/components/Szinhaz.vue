<!-- Szinhaz.vue -->

<template>
  <div>
    <h1>Színházak és Előadásaik</h1>
    <ul>
      <li v-for="szinhaz in szinhazak" :key="szinhaz.neve">
        <h2>{{ szinhaz.neve }}</h2>
        <ul>
          <li v-for="el in szinhaz.eloadasok" :key="el.cim">
            <a :href="el.url" target="_blank">{{ el.cim }}</a>
          </li>
        </ul>
      </li>
    </ul>
  </div>
</template>

<script>
import { SzinhazakStore } from '../stores/szinhaz.js';

export default {
  name: 'Szinhazak',
  setup() {
    const szinhaz = SzinhazakStore();
    return {
      szinhazak: szinhaz.szinhazak
    };
  }
};
</script>
