<template>
  <h1>Színházak és Előadásaik</h1>
  <select @change="ChangeItemView">
    <option v-for="item in szStore.szinhazak">
      {{ item.neve }}
    </option>
  </select>

  <div ref="kivalasztottEl">

  </div>
</template>

<script setup>
import { SzinhazakStore } from '../stores/szinhaz.js';
import {  ref } from 'vue';

let szStore = SzinhazakStore();
let kivalasztottEl = ref(null);

function ChangeItemView(e){
  kivalasztottEl.value.innerHTML = ""
  let kivalasztott = e.target.value;
  szStore.szinhazak.forEach(szinhaz => {
    if(szinhaz.neve == kivalasztott){
      let divelement = document.createElement("div")
      let szinhazcim = `<h2>${szinhaz.neve}</h2>`;
      let eloadascim = `<h2>Előadások:</h2>`
      divelement.insertAdjacentHTML("beforeend", szinhazcim);
      divelement.insertAdjacentHTML("beforeend", eloadascim);

      let lista = document.createElement("ul")

      szinhaz.eloadasok.forEach(eloadas => {
        lista.insertAdjacentHTML(`beforeend`,`
            <li>Cím: ${eloadas.cim}<br> Url: <a href="${eloadas.url}">link</a></li>
        
        
        `)
      });

      divelement.insertAdjacentElement("beforeend", lista)

      kivalasztottEl.value.insertAdjacentElement("beforeend",divelement)
      
    }
  });

}

</script>
