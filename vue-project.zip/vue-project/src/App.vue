<script setup>
import { RouterLink, RouterView } from 'vue-router'
import Szinhaz from "@/components/Szinhaz.vue";
</script>

<template>
  <Szinhaz/>
</template>
